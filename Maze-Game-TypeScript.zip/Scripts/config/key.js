var config;
(function (config) {
    var Key = /** @class */ (function () {
        function Key() {
        }
        // Keycode
        Key.LEFT = 37;
        Key.RIGHT = 39;
        Key.UP = 38;
        Key.DOWN = 40;
        Key.SPACE = 32;
        Key.F = 70;
        Key.G = 71;
        Key.V = 86;
        return Key;
    }());
    config.Key = Key;
})(config || (config = {}));
//# sourceMappingURL=key.js.map