var physics;
(function (physics) {
    var Config = /** @class */ (function () {
        function Config() {
        }
        Config.GRAVITY = 0;
        return Config;
    }());
    physics.Config = Config;
})(physics || (physics = {}));
//# sourceMappingURL=config.js.map