module physics{
    export class Config {
        public static readonly GRAVITY: number = 0;
    }
}